use qsl_examples::*;
fn main() -> Result<(), Box<dyn std::error::Error>> {
    let text = texts().remove(0);
    let plain = OwnedText { text: text.clone() };
    let bytes = plain.serialize_checked()?;
    let borrowed = BorrowedText::deserialize_checked(&bytes)?;
    let guard = GuardText::deserialize_checked(&bytes)?;
    let inline = InlineText {
        text: inline(&text)?,
    }
    .serialize_checked()?;
    let compressed = CompressedText {
        text: qsl_examples::inline(&text)?,
    }
    .serialize_checked()?;
    println!(
        "{} UTF-8 characters = {} bytes; String/borrow/guard frame={} B; inline={} B; LZ={} B",
        text.chars().count(),
        text.len(),
        bytes.len(),
        inline.len(),
        compressed.len()
    );
    println!(
        "borrowed={} chars, copied guard={} bytes; fixed string Rust type: [u8; 4]",
        borrowed.text.chars().count(),
        guard.text.len()
    );
    assert_eq!(
        CompressedText::deserialize_checked(&compressed)?
            .text
            .as_str(),
        text
    );
    let fixed = FixedText { text: *b"rust" };
    assert_eq!(fixed.serialize_checked()?, b"rust");
    Ok(())
}
